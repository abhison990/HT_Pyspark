import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
import datetime


spark = SparkSession.builder \
.master("yarn") \
.appName("CS in HT") \
.config("hive.exec.dynamic.partition", "true")\
.config("hive.exec.dynamic.partition.mode", "nonstrict")\
.getOrCreate()

print("ETL Job execution started at ")

#Filter out all of the rows in Unpaid Services by DocNo where the Document Type equals any of the following {CF, EN, IC, #NP, PO, SR}, to exclude the unnecessary types of invoices nad keep the rest

unp_df = spark.sql("select * from stg_dwh.stg_sas_unpaid_services_by_docnum \
where Document_Type not in ('CF','EN','IC','NP','PO','SR')")

lock=spark.sql("select * from STG_DWH.stg_sas_lock_by_docnum_complaints")


df=unp_df.join(lock,"document_number","inner")
print(df)
df.registerTempTable('l')

df1=spark.sql("SELECT * FROM l WHERE l.keydate_prompt not between l.Lock_From_Date AND l.Lock_To_Date").show()			   
			   
coll = spark.sql("SELECT * FROM stg_dwh.stg_sas_collectionlevel_by_docno")

#For each remaining row in the Unpaid Services by DocNo table, find a corresponding Document Number in the Collection Level table 

join = df1.join(coll,"document_number","inner")
print(join)
join.registerTempTable('j')

joindf_cnt=join.count()
print("Total count after join is : " + str(joindf_cnt))

#and the latest Dunning Date preceding or equal to the Keydate,
df1=spark.sql("select Document_Number,keydate_prompt,amount,oib,collection_level,Dunning_Date,Dunning_Amount from j \
where Dunning_Date<=keydate_prompt")
df1.show()
df1_cnt=df1.count()
print("Total count after filtering is : " + str(df1_cnt))


##Add a column containing an interval for each of the Collection Levels, as requested by the vendor:
##0 à NO_DUN
##[1, 9]
##[10, 19]
##[20, 29]
##[30, 39]
##[40, 49]
##[50, 79]
##[80, 94]
##95
df2=df1.withColumn("Interval",f.expr("case when collection_level>=10 and collection_level<=19 then 1019\
                                        when collection_level>=20 and collection_level<=29 then 2029\
                                        when collection_level>=30 and collection_level<=39 then 3039\
                                        when collection_level>=40 and collection_level<=49 then 4049\
                                        when collection_level>=50 and collection_level<=79 then 5079\
                                        when collection_level>=80 and collection_level<=94 then 8094\
                                        when collection_level=95 then 95\
                                        when collection_level=0 then 'No_DUN' end"))

df2.show()
df2.registerTempTable('v')